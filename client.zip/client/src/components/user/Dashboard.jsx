import React, { useState, useEffect } from 'react';
import { Search, Filter, Star, MapPin, Clock, DollarSign, Calendar, Heart, Users, Award } from 'lucide-react';

const Dashboard = ({ user }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSpecialty, setSelectedSpecialty] = useState('');
  const [priceRange, setPriceRange] = useState('');
  const [trainers, setTrainers] = useState([]);
  const [loading, setLoading] = useState(true);

  // Mock trainers data
  useEffect(() => {
    setTimeout(() => {
      setTrainers([
        {
          id: 1,
          name: "Mike Johnson",
          specialties: ["Weight Training", "Bodybuilding"],
          rating: 4.9,
          reviews: 127,
          hourlyRate: 75,
          location: "Downtown Gym",
          experience: 8,
          image: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400&h=400&fit=crop&crop=face",
          bio: "Certified bodybuilding coach with 8+ years of experience helping clients achieve their fitness goals.",
          availability: "Mon-Fri"
        },
        {
          id: 2,
          name: "Sarah Williams",
          specialties: ["Yoga", "Pilates", "Flexibility"],
          rating: 4.8,
          reviews: 89,
          hourlyRate: 60,
          location: "Wellness Center",
          experience: 5,
          image: "https://images.unsplash.com/photo-1594736797933-d0f1dcb14d8f?w=400&h=400&fit=crop&crop=face",
          bio: "Yoga instructor specializing in mindfulness and flexibility training for all levels.",
          availability: "Daily"
        },
        {
          id: 3,
          name: "David Chen",
          specialties: ["CrossFit", "HIIT", "Strength"],
          rating: 4.7,
          reviews: 156,
          hourlyRate: 80,
          location: "CrossFit Box",
          experience: 6,
          image: "https://images.unsplash.com/photo-1567013127542-490d757e51cd?w=400&h=400&fit=crop&crop=face",
          bio: "High-intensity training specialist focused on functional fitness and athletic performance.",
          availability: "Mon-Sat"
        },
        {
          id: 4,
          name: "Emma Rodriguez",
          specialties: ["Cardio", "Weight Loss", "Nutrition"],
          rating: 4.9,
          reviews: 203,
          hourlyRate: 70,
          location: "Fitness Hub",
          experience: 7,
          image: "https://images.unsplash.com/photo-1559539708-f3792e71aa4b?w=400&h=400&fit=crop&crop=face",
          bio: "Nutrition and fitness coach helping clients achieve sustainable weight loss and healthy lifestyle.",
          availability: "Mon-Fri"
        },
        {
          id: 5,
          name: "Alex Thompson",
          specialties: ["Powerlifting", "Strength", "Competition Prep"],
          rating: 4.8,
          reviews: 94,
          hourlyRate: 85,
          location: "Iron Gym",
          experience: 10,
          image: "https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&h=400&fit=crop&crop=face",
          bio: "Powerlifting champion and coach specializing in strength training and competition preparation.",
          availability: "Tue-Sun"
        },
        {
          id: 6,
          name: "Lisa Park",
          specialties: ["Dance Fitness", "Zumba", "Cardio"],
          rating: 4.6,
          reviews: 78,
          hourlyRate: 55,
          location: "Dance Studio",
          experience: 4,
          image: "https://images.unsplash.com/photo-1506629905607-47b5a87888a9?w=400&h=400&fit=crop&crop=face",
          bio: "Dance fitness instructor bringing fun and energy to every workout session.",
          availability: "Mon-Fri"
        }
      ]);
      setLoading(false);
    }, 1000);
  }, []);

  const specialties = ["Weight Training", "Yoga", "CrossFit", "Cardio", "Powerlifting", "Dance Fitness", "Pilates", "HIIT"];

  const filteredTrainers = trainers.filter(trainer => {
    const matchesSearch = trainer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         trainer.specialties.some(spec => spec.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesSpecialty = !selectedSpecialty || trainer.specialties.includes(selectedSpecialty);
    const matchesPrice = !priceRange || 
      (priceRange === 'low' && trainer.hourlyRate < 60) ||
      (priceRange === 'medium' && trainer.hourlyRate >= 60 && trainer.hourlyRate < 80) ||
      (priceRange === 'high' && trainer.hourlyRate >= 80);
    
    return matchesSearch && matchesSpecialty && matchesPrice;
  });

  const renderStars = (rating) => {
    return [...Array(5)].map((_, i) => (
      <Star 
        key={i} 
        className={`w-4 h-4 ${i < Math.floor(rating) ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} 
      />
    ));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Hero Section */}
      <div className="relative py-20 px-4">
        <div className="absolute inset-0 bg-gradient-to-r from-purple-600/20 to-pink-600/20"></div>
        <div className="relative max-w-6xl mx-auto text-center">
          <h1 className="text-5xl font-bold text-white mb-4">
            Welcome back, <span className="text-purple-400">{user?.name}!</span>
          </h1>
          <p className="text-xl text-gray-300 mb-8">Find the perfect trainer to achieve your fitness goals</p>
          
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
              <Users className="w-8 h-8 text-purple-400 mb-3" />
              <div className="text-2xl font-bold text-white">{trainers.length}+</div>
              <div className="text-gray-300">Expert Trainers</div>
            </div>
            <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
              <Award className="w-8 h-8 text-green-400 mb-3" />
              <div className="text-2xl font-bold text-white">4.8</div>
              <div className="text-gray-300">Average Rating</div>
            </div>
            <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
              <Clock className="w-8 h-8 text-blue-400 mb-3" />
              <div className="text-2xl font-bold text-white">24/7</div>
              <div className="text-gray-300">Available</div>
            </div>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="max-w-6xl mx-auto px-4 mb-12">
        <div className="bg-white/10 backdrop-blur-lg rounded-3xl p-6 border border-white/20">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search trainers..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-12 pr-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>

            {/* Specialty Filter */}
            <div className="relative">
              <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <select
                value={selectedSpecialty}
                onChange={(e) => setSelectedSpecialty(e.target.value)}
                className="w-full pl-12 pr-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-purple-500 appearance-none"
              >
                <option value="" className="bg-gray-800">All Specialties</option>
                {specialties.map(spec => (
                  <option key={spec} value={spec} className="bg-gray-800">{spec}</option>
                ))}
              </select>
            </div>

            {/* Price Range */}
            <div className="relative">
              <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <select
                value={priceRange}
                onChange={(e) => setPriceRange(e.target.value)}
                className="w-full pl-12 pr-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-purple-500 appearance-none"
              >
                <option value="" className="bg-gray-800">All Prices</option>
                <option value="low" className="bg-gray-800">Under $60/hr</option>
                <option value="medium" className="bg-gray-800">$60-80/hr</option>
                <option value="high" className="bg-gray-800">$80+/hr</option>
              </select>
            </div>

            {/* Clear Filters */}
            <button
              onClick={() => {
                setSearchTerm('');
                setSelectedSpecialty('');
                setPriceRange('');
              }}
              className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-semibold py-3 px-6 rounded-xl transition-all duration-300 transform hover:scale-105"
            >
              Clear Filters
            </button>
          </div>
        </div>
      </div>

      {/* Trainers Grid */}
      <div className="max-w-6xl mx-auto px-4 pb-12">
        <div className="mb-6">
          <h2 className="text-2xl font-bold text-white mb-2">Available Trainers</h2>
          <p className="text-gray-300">{filteredTrainers.length} trainers found</p>
        </div>

        {loading ? (
          <div className="flex justify-center items-center py-12">
            <div className="w-12 h-12 border-4 border-purple-500 border-t-transparent rounded-full animate-spin"></div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredTrainers.map(trainer => (
              <div key={trainer.id} className="bg-white/10 backdrop-blur-lg rounded-3xl border border-white/20 overflow-hidden hover:bg-white/15 transition-all duration-300 transform hover:-translate-y-2 hover:shadow-2xl">
                {/* Trainer Image */}
                <div className="relative h-48 bg-gradient-to-br from-purple-600 to-pink-600">
                  <img 
                    src={trainer.image} 
                    alt={trainer.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-4 right-4">
                    <button className="bg-white/20 backdrop-blur-sm p-2 rounded-full hover:bg-white/30 transition-colors">
                      <Heart className="w-5 h-5 text-white" />
                    </button>
                  </div>
                  <div className="absolute bottom-4 left-4 bg-black/50 backdrop-blur-sm px-3 py-1 rounded-full">
                    <div className="flex items-center text-white text-sm">
                      <Star className="w-4 h-4 text-yellow-400 fill-current mr-1" />
                      {trainer.rating} ({trainer.reviews})
                    </div>
                  </div>
                </div>

                {/* Trainer Info */}
                <div className="p-6">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <h3 className="text-xl font-bold text-white mb-1">{trainer.name}</h3>
                      <div className="flex items-center text-gray-300 text-sm mb-2">
                        <MapPin className="w-4 h-4 mr-1" />
                        {trainer.location}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-purple-400">${trainer.hourlyRate}</div>
                      <div className="text-gray-300 text-sm">per hour</div>
                    </div>
                  </div>

                  {/* Specialties */}
                  <div className="flex flex-wrap gap-2 mb-4">
                    {trainer.specialties.slice(0, 2).map(specialty => (
                      <span key={specialty} className="bg-purple-500/30 text-purple-200 px-3 py-1 rounded-full text-sm">
                        {specialty}
                      </span>
                    ))}
                    {trainer.specialties.length > 2 && (
                      <span className="bg-gray-500/30 text-gray-300 px-3 py-1 rounded-full text-sm">
                        +{trainer.specialties.length - 2} more
                      </span>
                    )}
                  </div>

                  <p className="text-gray-300 text-sm mb-4 line-clamp-2">{trainer.bio}</p>

                  {/* Stats */}
                  <div className="flex justify-between text-sm text-gray-300 mb-4">
                    <div className="flex items-center">
                      <Award className="w-4 h-4 mr-1" />
                      {trainer.experience} years
                    </div>
                    <div className="flex items-center">
                      <Clock className="w-4 h-4 mr-1" />
                      {trainer.availability}
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-3">
                    <button className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-semibold py-3 rounded-xl transition-all duration-300 transform hover:scale-105">
                      Book Session
                    </button>
                    <button className="bg-white/10 hover:bg-white/20 border border-white/20 text-white p-3 rounded-xl transition-all duration-300">
                      <Calendar className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {filteredTrainers.length === 0 && !loading && (
          <div className="text-center py-12">
            <div className="text-6xl mb-4">😔</div>
            <h3 className="text-xl font-semibold text-white mb-2">No trainers found</h3>
            <p className="text-gray-300">Try adjusting your search criteria</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
